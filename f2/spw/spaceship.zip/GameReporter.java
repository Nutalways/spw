public interface GameReporter {

	long getScore();
	int getHpScore();

}
